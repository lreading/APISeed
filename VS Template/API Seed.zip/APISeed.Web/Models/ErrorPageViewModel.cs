﻿namespace $safeprojectname$.Models
{
    public class ErrorPageViewModel
    {
        public string Title { get; set; }
        public string Message { get; set; }
    }
}
