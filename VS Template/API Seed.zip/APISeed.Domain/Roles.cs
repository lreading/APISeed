﻿namespace $safeprojectname$
{
    /// <summary>
    /// The available roles for this application
    /// </summary>
    public enum Roles
    {
        Administrator
    }
}
